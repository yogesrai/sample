﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Mvc.Models
{
    public class mvctblUser
    {
        public int UserId { get; set; }
        [Required(ErrorMessage="This Field is Required")]
        public string Username { get; set; }
        public string Password { get; set; }
        public string Usertype { get; set; }
        public string Fullname { get; set; }
    }
}