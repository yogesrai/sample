﻿using Mvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace Mvc.Controllers
{
    public class tblUserController : Controller
    {
        // GET: tblUser
        public ActionResult Index()
        {
            IEnumerable<mvctblUser> tbllist;
            HttpResponseMessage response = GlobalVariables.webapiclient.GetAsync("tblUsers").Result;
            tbllist = response.Content.ReadAsAsync<IEnumerable<mvctblUser>>().Result;
            return View(tbllist);
        }
        public ActionResult AddOrEdit(int id = 0)
        {
            if (id==0)
            return View(new mvctblUser());
            else
            {
                HttpResponseMessage response = GlobalVariables.webapiclient.GetAsync("tblUsers/"+id.ToString()).Result;
                return View(response.Content.ReadAsAsync<mvctblUser>().Result);
            }
        }
        [HttpPost]
        public ActionResult AddOrEdit(mvctblUser mtu)
        {
            if (mtu.UserId == 0)
            {
                HttpResponseMessage response = GlobalVariables.webapiclient.PostAsJsonAsync("tblUsers", mtu).Result;
                TempData["SuccessMessage"] = "Saved Successfully";
            }
            else
            {
                HttpResponseMessage response = GlobalVariables.webapiclient.PutAsJsonAsync("tblUsers/"+mtu.UserId, mtu).Result;
                TempData["SuccessMessage"] = "Updated Successfully";
            }
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = GlobalVariables.webapiclient.DeleteAsync("tblUsers/" + id.ToString()).Result;
            TempData["SuccessMessage"] = "Deleted Successfully";
            return RedirectToAction("Index");
        }
    }
}